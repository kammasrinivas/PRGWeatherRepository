import pandas as pd
from TMHPW_ETL import forecasts, exposures, Speedwell


def retrieved_forecast_data(year, month, day, hour, forecast_type, exp_list):
    if forecast_type == 'IFS':
        dfs = forecasts.IFS.retrieve_forecast_data(year, month, day, hour,
                                                   exp_list)
    elif forecast_type == 'AIFS':
        dfs = forecasts.AIFS.retrieve_forecast_data(year, month, day, hour,
                                                    exp_list)
    elif forecast_type == 'GFS':
        dfs = forecasts.GFS.retrieve_forecast_data(year, month, day, hour,
                                                   exp_list)


def perform_operation(s3_url, files, forecast_type, exp_list):
    df = pd.read_parquet(s3_url)
    fcsts_present = list(set(df.fcst_time))
    for i in range(len(files)):
        year = files[i].split('_')[-1][:4]
        month = files[i].split('_')[-1][4:6]
        day = files[i].split('_')[-1][6:8]
        hour = files[i].split('_')[-1][8:10]
        present = False
        for j in fcsts_present:
            if (j.year == int(year))*(j.month == int(month))*(j.day == int(day))*(j.hour == int(hour)):
                present = True
        if not present:
            print(year, month, day, hour)
            retrieved_forecast_data(year, month, day, hour, 
                                    forecast_type, exp_list)


def lambda_handler(events, context):
    exp_list = exposures.get_monitored_exposures()
    Speedwell.retrieve_exposures(exp_list, 'tmean')
    ffiles = None
    s3_url = None

    # IFS Forecast
    print("Processing IFS Forecast")
    ffiles = forecasts.IFS.get_available_forecasts('IFS_enfo_t2m_fcst_cf_')
    s3_url = 's3://non-cat-weather-data/monitored_exposures/{}/{}/forecast/IFS_enfo_{}.parquet'.format('AMS', 't2m', 'AMS')
    perform_operation(s3_url, ffiles, "IFS", exp_list)
    print("IFS forecast processing completed")

    #  AIFS Forecast
    print("Processing AIFS Forecast")
    ffiles = forecasts.IFS.get_available_forecasts('AIFS')
    s3_url = 's3://non-cat-weather-data/monitored_exposures/{}/{}/forecast/AIFS_{}.parquet'.format('AMS', 't2m', 'AMS')
    perform_operation(s3_url, ffiles, "AIFS", exp_list)
    print("AIFS forecast processing completed")
  
    # GFS Forecast
    print("Processing GFS Forecast")
    ffiles = forecasts.IFS.get_available_forecasts('GFS')
    s3_url = 's3://non-cat-weather-data/monitored_exposures/{}/{}/forecast/GFS_{}.parquet'.format('AMS', 't2m', 'AMS')
    perform_operation(s3_url, ffiles, "GFS", exp_list)
    print("GFS forecast processing completed")
if __name__ == "__main__":
    lambda_handler({},{})